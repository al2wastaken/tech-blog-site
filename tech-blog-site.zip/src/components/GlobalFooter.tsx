import React from "react";
import Footer from "./Footer";

export default function GlobalFooter() {
  return <Footer />;
}
